package clockwise;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Created by spayam on 24-Mar-19.
 */
public class ClockwiseSpiral {


    public int[] printArrayClockwise(int[][] array) {
       throw new NotImplementedException();
    }


}
